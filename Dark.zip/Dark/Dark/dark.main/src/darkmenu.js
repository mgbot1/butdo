const menuboa = (prefix) => {
	return `

            COMANDOS:




😡 *${prefix}germana*
😡 *${prefix}hentai*
😡 *${prefix}dono*
😡 *${prefix}porno*
😡 *${prefix}boanoite*
😡 *${prefix}bomdia*
😡 *${prefix}boatarde*
😡 *${prefix}mia*
😡 *${prefix}mia1*
😡 *${prefix}mia2*
😡 *${prefix}belle*
😡 *${prefix}belle1*
😡 *${prefix}belle2*
😡 *${prefix}belle3*
😡 *${prefix}ayeko*

╔════════════════════
  By: 𝘼𝙣𝙙𝙧𝙖𝙙𝙚 𝙈𝙤𝙙𝙙𝙚𝙧 (𝙑𝙪𝙡𝙜𝙤 𝙈𝙖𝙜𝙤)
╚════════════════════`
}

exports.menuboa = menuboa










